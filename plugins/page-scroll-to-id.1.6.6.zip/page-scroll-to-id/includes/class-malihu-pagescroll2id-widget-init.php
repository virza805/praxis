<?php
add_action('widgets_init', function(){
	register_widget('malihuPageScroll2idWidget');
});
?>